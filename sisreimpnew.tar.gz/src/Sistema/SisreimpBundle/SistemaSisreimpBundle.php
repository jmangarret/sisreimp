<?php

namespace Sistema\SisreimpBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SistemaSisreimpBundle extends Bundle
{
}
